// /src/config/contracts/accountFactories.ts

// List factory address contract - tambahkan sesuai kebutuhan dan akan dipilih satu di index.ts
export const factoryNOTA = "0x186b1740d24bc028D220838796441441dc444f9A"; // Prof. NOTA Inc.
export const factoryVoyage = "0x186b1740d24bc028D220838796441441dc444f9A"; // BON VOYAGE

// // // // // // // // // // // // // // // // // // // // // // // // // // // // // // // // // // // // //
